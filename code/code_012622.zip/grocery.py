# Item: Bread, Price: $ 2.99
# Item: Eggs, Price: $ 1.99

item_1 = "Cheese"
item_2 = "Eggs"
item_1_price = 3.99
item_2_price = 1.99

print("Item:", item_1, "Price: $", item_1_price)
print("Item:", item_2, "Price: $", item_2_price)
