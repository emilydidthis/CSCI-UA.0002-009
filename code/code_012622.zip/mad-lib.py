noun = input ("Noun: ")
verb = input ("Verb: ")
adjective = input ("Adjective: ")
adverb = input ("Adverb: ")

# Below I will output the mad lib
print ("The", adjective, noun, "was very hungry, so it decided to", adverb, verb, "to the nearest restaurant.")
