score1 = 100
score2 = 94
score3 = 88

# Individual scores: 100, 94, 88

print("Individual scores: " + str(score1) + ", " \
      + str(score2) + ", " + str(score3))

