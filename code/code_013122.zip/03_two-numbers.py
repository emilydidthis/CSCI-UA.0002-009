# ask user for two floating point numbers

num_1 = input("First number: ")
num_2 = input("Second number: ")

# compute sum, product, difference, first number divided by second

sum = float(num_1) + float(num_2)
prod_float = float(num_1) * float(num_2)
diff_float = float(num_1) - float(num_2)
div_float = float(num_1) / float(num_2)

print("Sum:", sum)
print("Product:", prod_float)
print("Difference:", diff_float)
print("First number divided by second:", div_float)



