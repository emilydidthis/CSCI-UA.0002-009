# Programming Challenge: Subway Ride Calculator

# ask user for value of current MetroCard
mc_value = float(input("Value of Metrocard: "))

# compute rides left in whole numbers
rides_left = mc_value // 2.75
print("Rides left:", int(rides_left))



